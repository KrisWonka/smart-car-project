#define PATCH_METHOD 0  // 0: 最小二乘法  1: 斜率延伸  2: 多项式拟合
