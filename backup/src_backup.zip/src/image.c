#include "image.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

uint8_t original_image[IMAGE_H][IMAGE_W];
uint8_t bin_image[IMAGE_H][IMAGE_W];
int points_l[MAX_POINTS][2];
int points_r[MAX_POINTS][2];
int dir_l[MAX_POINTS];
int dir_r[MAX_POINTS];
int l_border[IMAGE_H];
int r_border[IMAGE_H];
int center_line[IMAGE_H];
int l_count, r_count, hightest;

void read_pgm(const char *filename)
{
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        printf("Error opening image\n");
        exit(1);
    }
    char header[20];
    fread(header, sizeof(char), 15, fp);
    fread(original_image, sizeof(uint8_t), IMAGE_W * IMAGE_H, fp);
    fclose(fp);
}

void save_pgm(const char *filename, uint8_t image[IMAGE_H][IMAGE_W])
{
    FILE *fp = fopen(filename, "wb");
    fprintf(fp, "P5\n%d %d\n255\n", IMAGE_W, IMAGE_H);
    fwrite(image, sizeof(uint8_t), IMAGE_W * IMAGE_H, fp);
    fclose(fp);
}

void turn_to_bin(void)
{
    int hist[256] = {0};
    int total = IMAGE_W * IMAGE_H;
    for (int i = 0; i < IMAGE_H; i++)
        for (int j = 0; j < IMAGE_W; j++)
            hist[original_image[i][j]]++;

    int sum = 0, sumB = 0, q1 = 0, q2 = 0;
    double maxVar = 0;
    uint8_t threshold = 0;

    for (int i = 0; i < 256; i++) sum += i * hist[i];

    for (int t = 0; t < 256; t++) {
        q1 += hist[t];
        if (q1 == 0) continue;
        q2 = total - q1;
        if (q2 == 0) break;
        sumB += t * hist[t];
        double m1 = (double)sumB / q1;
        double m2 = (double)(sum - sumB) / q2;
        double varBetween = (double)q1 * q2 * (m1 - m2) * (m1 - m2);
        if (varBetween > maxVar) {
            maxVar = varBetween;
            threshold = t;
        }
    }

    for (int i = 0; i < IMAGE_H; i++)
        for (int j = 0; j < IMAGE_W; j++)
            bin_image[i][j] = (original_image[i][j] < threshold) ? WHITE_PIXEL : BLACK_PIXEL;
}

void get_start_point(int start_row, int *l_x, int *l_y, int *r_x, int *r_y)
{
    *l_x = 0; *l_y = start_row;
    *r_x = 0; *r_y = start_row;

    for (int i = IMAGE_W / 2; i > BORDER_MIN; i--)
        if (bin_image[start_row][i] == 255 && bin_image[start_row][i - 1] == 0) {
            *l_x = i;
            break;
        }

    for (int i = IMAGE_W / 2; i < BORDER_MAX; i++)
        if (bin_image[start_row][i] == 255 && bin_image[start_row][i + 1] == 0) {
            *r_x = i;
            break;
        }
}

void search_l_r(int l_start_x, int l_start_y, int r_start_x, int r_start_y)
{
    const int8_t seeds_l[8][2] = { {0,1},{-1,1},{-1,0},{-1,-1},{0,-1},{1,-1},{1,0},{1,1} };
    const int8_t seeds_r[8][2] = { {0,1},{1,1},{1,0},{1,-1},{0,-1},{-1,-1},{-1,0},{-1,1} };

    int cx_l = l_start_x, cy_l = l_start_y;
    int cx_r = r_start_x, cy_r = r_start_y;
    l_count = r_count = 0;
    hightest = 0;

    for (int iter = 0; iter < MAX_POINTS; iter++) {
        points_l[l_count][0] = cx_l;
        points_l[l_count][1] = cy_l;
        l_count++;

        points_r[r_count][0] = cx_r;
        points_r[r_count][1] = cy_r;
        r_count++;

        int found = 0;
        for (int i = 0; i < 8; i++) {
            int nx = cx_l + seeds_l[i][0];
            int ny = cy_l + seeds_l[i][1];
            int nxn = cx_l + seeds_l[(i + 1) & 7][0];
            int nyn = cy_l + seeds_l[(i + 1) & 7][1];
            if (bin_image[ny][nx] == 0 && bin_image[nyn][nxn] == 255) {
                cx_l = nx;
                cy_l = ny;
                dir_l[l_count - 1] = i;
                found = 1;
                break;
            }
        }
        if (!found) break;

        found = 0;
        for (int i = 0; i < 8; i++) {
            int nx = cx_r + seeds_r[i][0];
            int ny = cy_r + seeds_r[i][1];
            int nxn = cx_r + seeds_r[(i + 1) & 7][0];
            int nyn = cy_r + seeds_r[(i + 1) & 7][1];
            if (bin_image[ny][nx] == 0 && bin_image[nyn][nxn] == 255) {
                cx_r = nx;
                cy_r = ny;
                dir_r[r_count - 1] = i;
                found = 1;
                break;
            }
        }
        if (!found) break;

        if (abs(cx_r - cx_l) <= 1 && abs(cy_r - cy_l) <= 1) {
            hightest = (cy_r + cy_l) >> 1;
            break;
        }
        if (cy_r < cy_l) continue;
    }
}

void get_left(void)
{
    for (int i = 0; i < IMAGE_H; i++) l_border[i] = BORDER_MIN;

    for (int i = 0; i < l_count; i++) {
        int y = points_l[i][1];
        int x = points_l[i][0];
        if (l_border[y] == BORDER_MIN) l_border[y] = x + 1;
    }
}

void get_right(void)
{
    for (int i = 0; i < IMAGE_H; i++) r_border[i] = BORDER_MAX;

    for (int i = 0; i < r_count; i++) {
        int y = points_r[i][1];
        int x = points_r[i][0];
        if (r_border[y] == BORDER_MAX) r_border[y] = x - 1;
    }
}

void compute_center_line(void)
{
    for (int i = 0; i < IMAGE_H; i++) {
        center_line[i] = (l_border[i] + r_border[i]) >> 1;
    }
}

void save_borders(void)
{
    FILE *fp = fopen("border_output.txt", "w");
    for (int i = 0; i < IMAGE_H; i++) {
        fprintf(fp, "Row %d: L=%d R=%d C=%d\n", i, l_border[i], r_border[i], center_line[i]);
    }
    fclose(fp);
}

// 最小二乘法求斜率 k 和截距 b
void linear_regression(int y_start, int y_end, int *border, double *k, double *b)
{
    int n = y_end - y_start + 1;
    double sum_x = 0, sum_y = 0, sum_x2 = 0, sum_xy = 0;

    for (int i = y_start; i <= y_end; i++) {
        sum_x += i;
        sum_y += border[i];
        sum_x2 += i * i;
        sum_xy += i * border[i];
    }

    *k = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x);
    *b = (sum_y - (*k) * sum_x) / n;
}

// 补线函数
void patch_lines(void)
{
    int break_num_l = 0, break_num_r = 0;

    // 找左拐点
    for (int i = 1; i < l_count - 1; i++) {
        if (dir_l[i] == 4 && dir_l[i - 1] == 2) {
            break_num_l = points_l[i][1];
            break;
        }
    }
    // 找右拐点
    for (int i = 1; i < r_count - 1; i++) {
        if (dir_r[i] == 4 && dir_r[i - 1] == 6) {
            break_num_r = points_r[i][1];
            break;
        }
    }

    // 补左边
    if (break_num_l > 15) {
        double k, b;
        linear_regression(break_num_l - 15, break_num_l - 5, l_border, &k, &b);
        for (int y = break_num_l; y < IMAGE_H; y++) {
            l_border[y] = (int)(k * y + b);
        }
    }

    // 补右边
    if (break_num_r > 15) {
        double k, b;
        linear_regression(break_num_r - 15, break_num_r - 5, r_border, &k, &b);
        for (int y = break_num_r; y < IMAGE_H; y++) {
            r_border[y] = (int)(k * y + b);
        }
    }
}


void draw_center_line(void)
{
    for (int i = 0; i < IMAGE_H; i++) {
        if (center_line[i] >= 0 && center_line[i] < IMAGE_W)
            bin_image[i][center_line[i]] = 128; // 设置为灰色
    }
}

void process_current_frame(void)
{
    turn_to_bin();
    int l_x, l_y, r_x, r_y;
    get_start_point(IMAGE_H - 2, &l_x, &l_y, &r_x, &r_y);
    search_l_r(l_x, l_y, r_x, r_y);
    get_left();
    get_right();
    patch_lines();
    compute_center_line();
    draw_center_line(); // 添加这一行
    save_pgm("binary_output.pgm", bin_image);
    save_borders();
}