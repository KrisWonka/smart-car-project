#ifndef CONFIG_H
#define CONFIG_H

#define PATCH_METHOD 0  // 0: 最小二乘法  1: 斜率延伸  2: 多项式拟合 3:kalman滤波

#endif