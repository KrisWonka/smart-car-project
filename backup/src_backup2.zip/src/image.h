#ifndef IMAGE_H

#include <stdint.h>

#define IMAGE_W 188
#define IMAGE_H 120
#define MAX_POINTS 5000
#define WHITE_PIXEL 255
#define BLACK_PIXEL 0
#define BORDER_MIN 1
#define BORDER_MAX (IMAGE_W - 2)

#ifdef __cplusplus
extern "C" {
#endif

extern uint8_t original_image[IMAGE_H][IMAGE_W];
extern uint8_t bin_image[IMAGE_H][IMAGE_W];
extern int l_border[IMAGE_H];
extern int r_border[IMAGE_H];
extern int center_line[IMAGE_H];

void read_pgm(const char *filename);
void save_pgm(const char *filename, uint8_t image[IMAGE_H][IMAGE_W]);
void turn_to_bin(void);
void get_start_point(int start_row, int *l_x, int *l_y, int *r_x, int *r_y);
void search_l_r(int l_start_x, int l_start_y, int r_start_x, int r_start_y);
void get_left(void);
void get_right(void);
void compute_center_line(void);
void save_borders(void);
void process_current_frame(void);
void patch_lines_least_square(void);
void patch_lines_slope(void);
void patch_lines_poly(void);
void patch_lines_kalman(void);
#ifdef __cplusplus
}
#endif

#endif