#include "image.h"
#include <stdio.h>

int main()
{
    image_process();
    printf("✅ 处理完成，结果已保存\n");
    return 0;
}