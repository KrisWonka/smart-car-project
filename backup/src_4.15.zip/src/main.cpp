#include <opencv2/opencv.hpp>
#include <stdio.h>
#include "image.h" // 头文件
#include "config.h" // 补线配置文件
#include <time.h>

extern "C" {
    void process_current_frame(void); // 声明 C 函数
}

int main()
{   struct timespec last_time, current_time;
    int frame_counter = 0;
    double elapsed;
    
    clock_gettime(CLOCK_MONOTONIC, &last_time);
    
    // 初始化摄像头
    cv::VideoCapture cap(8);//摄像头编号
    // 设置相机参数
    // cap.set(cv::CAP_PROP_FRAME_WIDTH, 320);
    // cap.set(cv::CAP_PROP_FRAME_HEIGHT, 240);
    cap.set(cv::CAP_PROP_FPS, 90);


    if (!cap.isOpened()) {
        printf("摄像头打开失败\n");
        return -1;
    }

    const char* method_names[] = {"最小二乘法", "斜率延伸法", "多项式拟合法", "卡尔曼滤波"};
    printf("[INFO] 当前补线方法: %s\n", method_names[PATCH_METHOD]);

    while (1) {
        cv::Mat frame;
        cap >> frame;
        if (frame.empty()) continue;

        // 转灰度
        cv::Mat gray;
        cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
        cv::resize(gray, gray, cv::Size(IMAGE_W, IMAGE_H)); // 尺寸适配

        // 复制到 C 数组
        memcpy(original_image, gray.data, IMAGE_W * IMAGE_H);

        // 调用图像处理算法
        process_current_frame();

        // 计算偏移量 & 打印
        int sum = 0;
        for (int i = IMAGE_H - 10; i < IMAGE_H; i++)
            sum += center_line_final[i];
        int offset = (sum / 10) - (IMAGE_W / 2)+11;
        // printf("偏移量: %d\n", offset);

        // 加串口发送 offset 给小车



        // 把处理后的 bin_image 转回 Mat 显示
        cv::Mat processed(IMAGE_H, IMAGE_W, CV_8UC1);
        for (int i = 0; i < IMAGE_H; i++) {
            for (int j = 0; j < IMAGE_W; j++) {
                processed.at<uint8_t>(i, j) = bin_image[i][j];
            }
        }
        // 放大显示 (否则188x120)
        cv::Mat resized;
        cv::resize(processed, resized, cv::Size(IMAGE_W * 4, IMAGE_H * 4));

        // 显示处理后的图像
        cv::imshow("Processed Image", resized);
        // 显示原图像
        cv::imshow("frame", frame);
        if (cv::waitKey(1) == 27) break; // 按 ESC 退出

        // 计算帧率
        frame_counter++;
        clock_gettime(CLOCK_MONOTONIC, &current_time);
        elapsed = (current_time.tv_sec - last_time.tv_sec) + 
        (current_time.tv_nsec - last_time.tv_nsec) / 1e9;

        if (elapsed >= 1.0) {
            printf("FPS: %d\n", frame_counter);
            frame_counter = 0;
            last_time = current_time;
        }
    }

    return 0;
}
